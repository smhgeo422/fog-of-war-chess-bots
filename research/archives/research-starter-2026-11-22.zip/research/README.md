# FoW Research & Evidence Index

This folder is the durable **research record**, separate from runtime bot code. Started 2026-11-22. It is designed to merge into `smhgeo422/fog-of-war-chess-bots` after write permission is resolved. Its content does **not** claim the proposed experiments have run.

## Source of truth

- `idea_backlog.md`: original 46 proposed research experiments, paper references and current baseline evidence.
- `experiment_registry.jsonl`: 46 stable IDs and machine-readable status. Existing-code labels mean implemented foundation, **not validated as improvements**.
- `report_outline.md`: living report structure; fill conclusions only from verified results.
- `contributions.md`: evidence-backed individual ownership and AI assistance. Never claim authorship of teammates' prior code.
- `decisions.md`: chronological decisions and why each direction was adopted or rejected.
- `results_index.md`: links to stored experiment artifacts and their checksums.
- `templates/experiment_card.md`: use one card per test or ablation under `research/experiments/<ID>-<slug>.md` (directory created when needed).

## Integration with the already-built Phase 2 infrastructure

Use the **existing**, currently unpublished Phase 2 code under `experiments/` for configs, run manifests, registries, and reproducible reports. Do not create a competing runner or overwrite the existing configuration files. The Phase 2 code is in the preserved Git bundle at commit `01f405174bf99f66fbaef508aef45c2ecd803a47`, requiring base commit `580618950b9925521229bc076169967de2d87048`.

Each research ID (e.g., `C01`) can have multiple run IDs (e.g., `C01-hang-0p5-v4-20261124a`). Store executable config under `experiments/configs/`, short report summaries under `research/experiments/`, and put large replays and logs in a private external archive (or committed small fixtures). **GitHub Actions artifacts alone expire** (currently configured at 30 days for validation and 90 days for experiment artifacts); copy important results to durable storage and record links and SHA-256 hashes in `results_index.md`.

Experiment lifecycle: `proposed` -> `specified` -> `implemented` -> `tests_passed` -> `screened` -> `confirmed` or `negative` or `inconclusive` / `blocked`. All state changes need evidence. The final bot should only combine tested candidates, and official arena submissions should be explicit and infrequent.

## Guardrails

- Preserve `bots/obscuro_v2`, `_v3`, `_v4`, `starter/`, and all frozen checksums.
- Never commit arena credentials, private replay access tokens, personal account secrets, proprietary datasets, `.env` contents, or credentials in logs. The team's previously pasted token should be rotated before use.
- Never use hidden full-board information from replays as an input to a playing bot. Replays may be used for training or offline evaluation only, subject to competition rules.
- Evaluate one changed factor at a time before testing combinations. Smoke tests capped after 12/20 plies are not evidence of playing strength.
- Record seed, environment variables, CPU quota, Stockfish binary and hash, time controls, full game count, opening/color pairing, opponents, commit SHA, W/D/L, confidence interval, crashes, and interpretation.

# Installation instructions (one-time)

This archive contains `research/` only, designed to merge into the existing project without overwriting the unfinished Phase 2 `experiments/` tooling. Verify GitHub write access before publishing, or let Codex continue using the Phase 2 archive and this research archive in its working environment.

After restoring the Phase 2 branch, copy this archive's `research/` directory to repository root. Verify the 46 registry entries, run tests, then commit on a new branch `research/experiment-records`. Do not rewrite the team's `APPROACHES.md`, frozen bot files, or original `docs/research` materials.

The research registry was generated from the planning document, not from run outputs. All experiments start as proposed or existing foundation requiring validation.

Restricted referee fixtures and locally regenerated Stage 2 synthetic games. The project-specific outcomes and limitations are in projects.json. This run contains zero playing-strength matches.

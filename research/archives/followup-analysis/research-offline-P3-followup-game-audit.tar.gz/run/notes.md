Post-Stage-7 replay follow-up. P3 scores shared bounded Stockfish tables. P1/P5 transfer checks are exploratory and use the same three game blocks. Results do not measure playing strength.

# stage4-b0-b2-smoke-20261122

eBotI and frozen obscuro_v4 can complete a color pair using their own required native components.

Candidate **eBotI** vs baseline **obscuro_v4**. 24+0.1, cap 20 plies, 2/2 recorded, 0 invalid. Root seed 7106, 1 worker(s).

This smoke run checks integration and provides no playing-strength evidence.

| Candidate games | N | W | D | L | Score |
|---|---:|---:|---:|---:|---:|
| All valid | 2 | 0 | 2 | 0 | 50.0% |
| white | 1 | 0 | 1 | 0 | 50.0% |
| black | 1 | 0 | 1 | 0 | 50.0% |

Complete color pairs · 1.
95% paired score interval · unavailable.

## Game lengths in plies

`{'n': 2, 'min': 20, 'median': 20.0, 'p90': 20, 'max': 20}`

## Clock usage in seconds

`{'candidate': {'n': 2, 'min': 1.255443, 'median': 1.7410435, 'p90': 1.255443, 'max': 2.226644}, 'baseline': {'n': 2, 'min': 7.250081, 'median': 7.2795795000000005, 'p90': 7.250081, 'max': 7.309078}}`

## Termination reasons

`{'Move limit reached': 2}`

## Failure codes

`{}`

## King safety and hidden captures

`{'candidate': {'king_attacked_post_move_frames': 0, 'hidden_captures_suffered_by_piece': {'b': 1}}, 'baseline': {'king_attacked_post_move_frames': 0, 'hidden_captures_suffered_by_piece': {}}}`

See `manifest.json` for revision, binaries and environment, and `report.json` for per-game data.

# followup-p3-game-positions

Collect paired short-clock reference histories for an offline reply-coverage and event-availability audit.

Candidate **eBotI** vs baseline **obscuro_v4**. 24+0.1, cap 100 plies, 6/6 recorded, 0 invalid. Root seed 87341, 1 worker(s).

This smoke run checks integration and provides no playing-strength evidence.

| Candidate games | N | W | D | L | Score |
|---|---:|---:|---:|---:|---:|
| All valid | 6 | 3 | 1 | 2 | 58.3% |
| white | 3 | 3 | 0 | 0 | 100.0% |
| black | 3 | 0 | 1 | 2 | 16.7% |

Complete color pairs · 3.
95% paired score interval · unavailable.

## Game lengths in plies

`{'n': 6, 'min': 56, 'median': 68.0, 'p90': 78, 'max': 100}`

## Clock usage in seconds

`{'candidate': {'n': 6, 'min': 8.785859, 'median': 10.966541, 'p90': 14.80594, 'max': 16.593497}, 'baseline': {'n': 6, 'min': 15.750188, 'median': 17.440889499999997, 'p90': 19.502725, 'max': 22.596024}}`

## Termination reasons

`{'King capturable': 5, 'Move limit reached': 1}`

## Failure codes

`{}`

## King safety and hidden captures

`{'candidate': {'king_attacked_post_move_frames': 8, 'hidden_captures_suffered_by_piece': {'n': 6, 'b': 6, 'p': 10, 'r': 3}}, 'baseline': {'king_attacked_post_move_frames': 15, 'hidden_captures_suffered_by_piece': {'b': 6, 'q': 1, 'r': 3, 'p': 10, 'n': 8}}}`

See `manifest.json` for revision, binaries and environment, and `report.json` for per-game data.
